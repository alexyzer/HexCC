package at.petrak.hexcasting.common.casting;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.casting.ActionRegistryEntry;
import at.petrak.hexcasting.api.casting.PatternShapeMatch;
import at.petrak.hexcasting.api.casting.castables.SpecialHandler;
import at.petrak.hexcasting.api.casting.eval.CastingEnvironment;
import at.petrak.hexcasting.api.casting.math.HexAngle;
import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.api.utils.HexUtils;
import at.petrak.hexcasting.server.ScrungledPatternsSave;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import com.mojang.datafixers.util.Pair;
import org.apache.commons.lang3.NotImplementedException;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import net.minecraft.class_3218;
import net.minecraft.class_5321;

// Now an internal-only class used to do final processing on the registered stuff
public class PatternRegistryManifest {
    private static final ConcurrentMap<List<HexAngle>, class_5321<ActionRegistryEntry>> NORMAL_ACTION_LOOKUP =
        new ConcurrentHashMap<>();

    /**
     * Process the registry!
     * <p>
     * This no longer checks any kind of per-world-pattern-ness because both this and ScrungledPatternsSave depends on
     * the other to be done first. lol lmao. It just caches signature->action for the non-per-world-pats
     * so it's an O(1) lookup.
     */
    // TODO i just realized that logically, this should not be run every time the client/server connects
    // just run it on startup, the info gathered here i think is static per world ... except for the per-worldies
    // that need to be recalced...
    //
    // Client is passed in currently for no reason, again will be required for shape-matching
    public static void processRegistry(@Nullable class_3218 overworld) {
        int perWorldActionCount = 0;

        var registry = IXplatAbstractions.INSTANCE.getActionRegistry();
        for (var key : registry.method_42021()) {
            var entry = registry.method_29107(key);
            if (entry == null)
                continue;

            if (!HexUtils.isOfTag(registry, key, HexTags.Actions.PER_WORLD_PATTERN)) {
                var old = NORMAL_ACTION_LOOKUP.put(entry.prototype().getAngles(), key);
                if (old != null) {
                    HexAPI.LOGGER.warn("Inserted %s which has same signature as %s, overriding it.".formatted(key, old));
                }
            } else {
                perWorldActionCount++;
            }
        }

        HexAPI.LOGGER.info(("We've loaded the pattern registry on the %s first! " +
            "Loaded %d regular actions, %d per-world actions, and %d special handlers").formatted(
            (overworld == null) ? "client" : "server", NORMAL_ACTION_LOOKUP.size(), perWorldActionCount,
            IXplatAbstractions.INSTANCE.getSpecialHandlerRegistry().method_10204()
        ));
    }

    /**
     * Try to match this pattern to a special handler. If one is found, return both the handler and its key.
     */
    @Nullable
    public static Pair<SpecialHandler, class_5321<SpecialHandler.Factory<?>>> matchPatternToSpecialHandler(HexPattern pat, CastingEnvironment environment) {
        var registry = IXplatAbstractions.INSTANCE.getSpecialHandlerRegistry();
        for (var key : registry.method_42021()) {
            var factory = registry.method_29107(key);
            if (factory == null)
                continue;
            var handler = factory.tryMatch(pat,environment);
            if (handler != null) {
                return Pair.of(handler, key);
            }
        }
        return null;
    }

    /**
     * Try to match this pattern to an action, whether via a normal pattern, a per-world pattern, or the machinations
     * of a special handler. Will never attempt to check alternate stroke orders, which always throws.
    */
    public static PatternShapeMatch matchPattern(HexPattern pat, CastingEnvironment environment) {
        // I am PURPOSELY checking normal actions before special handlers
        // This way we don't get a repeat of the phial number literal incident
        var sig = pat.getAngles();
        if (NORMAL_ACTION_LOOKUP.containsKey(sig)) {
            var key = NORMAL_ACTION_LOOKUP.get(sig);
            return new PatternShapeMatch.Normal(key);
        }

        // Look it up in the world?
        var perWorldPatterns = ScrungledPatternsSave.open(environment.getWorld().method_8503().method_30002());
        var entry = perWorldPatterns.lookup(pat.anglesSignature());
        if (entry != null) {
            return new PatternShapeMatch.PerWorld(entry.key(), true);
        }

        var shMatch = matchPatternToSpecialHandler(pat, environment);
        if (shMatch != null) {
            return new PatternShapeMatch.Special(shMatch.getSecond(), shMatch.getFirst());
        }

        return new PatternShapeMatch.Nothing();
    }

    @Nullable
    public static HexPattern getCanonicalStrokesPerWorld(class_5321<ActionRegistryEntry> key, class_3218 overworld) {
        var perWorldPatterns = ScrungledPatternsSave.open(overworld);

        var pair = perWorldPatterns.lookupReverse(key);
        if (pair == null) return null;

        var sig = pair.getFirst();
        var entry = pair.getSecond();
        return HexPattern.fromAnglesUnchecked(sig, entry.canonicalStartDir());
    }
}

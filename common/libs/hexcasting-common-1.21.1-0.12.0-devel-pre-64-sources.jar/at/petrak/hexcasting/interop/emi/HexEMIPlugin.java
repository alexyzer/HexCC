package at.petrak.hexcasting.interop.emi;

import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.common.recipe.BrainsweepRecipe;
import at.petrak.hexcasting.common.recipe.HexRecipeStuffRegistry;
import at.petrak.hexcasting.interop.utils.PhialRecipeStackBuilder;
import dev.emi.emi.api.EmiEntrypoint;
import dev.emi.emi.api.EmiPlugin;
import dev.emi.emi.api.EmiRegistry;
import dev.emi.emi.api.recipe.EmiRecipeCategory;
import dev.emi.emi.api.render.EmiTexture;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import net.minecraft.class_2960;
import net.minecraft.class_8786;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

@EmiEntrypoint
public class HexEMIPlugin implements EmiPlugin {
	private static final class_2960 BRAINSWEEP_ID = modLoc("brainsweep");
	public static final class_2960 PHIAL_ID = modLoc("craft/battery");
	public static final class_2960 EDIFY_ID = modLoc("edify");

	private static final class_2960 SIMPLIFIED_ICON_BRAINSWEEP = modLoc("textures/gui/brainsweep_recipe_icon.png");
	private static final class_2960 SIMPLIFIED_ICON_PHIAL = modLoc("textures/gui/phial_recipe_icon.png");
	private static final class_2960 SIMPLIFIED_ICON_EDIFY = modLoc("textures/gui/edify_recipe_icon.png");

	public static final EmiRecipeCategory BRAINSWEEP = new EmiRecipeCategory(BRAINSWEEP_ID,
		new PatternRendererEMI(BRAINSWEEP_ID, 16, 16),
		new EmiTexture(SIMPLIFIED_ICON_BRAINSWEEP, 0, 0, 16, 16, 16, 16, 16, 16));

	public static final EmiRecipeCategory PHIAL = new EmiRecipeCategory(PHIAL_ID,
		new PatternRendererEMI(PHIAL_ID, 12, 12).shift(2, 2),
		new EmiTexture(SIMPLIFIED_ICON_PHIAL, 0, 0, 16, 16, 16, 16, 16, 16));

	public static final EmiRecipeCategory EDIFY = new EmiRecipeCategory(EDIFY_ID,
		new PatternRendererEMI(EDIFY_ID, 16, 16).strokeOrder(false),
		new EmiTexture(SIMPLIFIED_ICON_EDIFY, 0, 0, 16, 16, 16, 16, 16, 16));

	@Override
	public void register(EmiRegistry registry) {
		registry.addCategory(BRAINSWEEP);
		registry.addCategory(PHIAL);
		registry.addCategory(EDIFY);
		registry.addWorkstation(BRAINSWEEP, EmiIngredient.of(HexTags.Items.STAVES));
		registry.addWorkstation(PHIAL, EmiIngredient.of(HexTags.Items.STAVES));
		registry.addWorkstation(EDIFY, EmiIngredient.of(HexTags.Items.STAVES));

		for (class_8786<BrainsweepRecipe> recipe : registry.getRecipeManager()
			.method_30027(HexRecipeStuffRegistry.BRAINSWEEP_TYPE.get())) {
			var inputBlocks = EmiIngredient.of(recipe.comp_1933().blockIn().getDisplayedStacks().stream()
				.map(EmiStack::of).toList());
			var inputEntity = new BrainsweepeeEmiStack(recipe.comp_1933().entityIn());
			var output = EmiStack.of(recipe.comp_1933().result().method_26204());
            var outputId = output.getId().method_12836().equals("minecraft") ? output.getId().method_12832() : output.getId().toString();
            var inputEntityId = inputEntity.getName().getString().toLowerCase().replaceAll(" ", "_");
            var recipeId = modLoc("/brainsweep/" + (outputId.replaceAll(":", "/")) + "_from_" + inputEntityId);
			registry.addRecipe(new EmiBrainsweepRecipe(inputBlocks, inputEntity, output, recipeId));
		}

		if (PhialRecipeStackBuilder.shouldAddRecipe()) {
			registry.addRecipe(new EmiPhialRecipe());
		}

		registry.addRecipe(new EmiEdifyRecipe());
	}
}

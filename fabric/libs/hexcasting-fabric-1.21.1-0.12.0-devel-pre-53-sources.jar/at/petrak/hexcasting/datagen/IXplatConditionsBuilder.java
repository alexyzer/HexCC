package at.petrak.hexcasting.datagen;

import net.minecraft.class_1792;
import net.minecraft.class_5797;
import net.minecraft.class_6862;

public interface IXplatConditionsBuilder extends class_5797 {
    IXplatConditionsBuilder whenModLoaded(String modid);

    IXplatConditionsBuilder whenModMissing(String modid);

    IXplatConditionsBuilder whenTagEmpty(class_6862<class_1792> tag);

    IXplatConditionsBuilder whenTagPopulated(class_6862<class_1792> tag);
}

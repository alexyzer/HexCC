package at.petrak.hexcasting.interop.jei;

import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.common.casting.actions.spells.OpMakeBattery;
import at.petrak.hexcasting.interop.utils.PhialRecipeStackBuilder;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.drawable.IDrawableStatic;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.class_1856;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import org.jetbrains.annotations.NotNull;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class PhialRecipeCategory implements IRecipeCategory<OpMakeBattery> {
    public static final class_2960 UID = modLoc("craft_phial");

    private final IDrawableStatic background;
    private final IDrawable icon;
    private final class_2561 localizedName;

    public PhialRecipeCategory(IGuiHelper guiHelper) {
        class_2960 location = modLoc("textures/gui/phial_recipe.png");
        background = guiHelper.drawableBuilder(location, 0, 0, 113, 40).setTextureSize(128, 128).build();
        var craftPhial = modLoc("craft/battery");
        localizedName = class_2561.method_43471("hexcasting.action." + craftPhial);
        icon = new PatternDrawable(craftPhial, 12, 12);
    }

    @Override
    public @NotNull class_2561 getTitle() {
        return localizedName;
    }

    @Override
    public int getWidth() {
        return background.getWidth();
    }

    @Override
    public int getHeight() {
        return background.getHeight();
    }

    @Override
    public void draw(OpMakeBattery recipe, IRecipeSlotsView recipeSlotsView, class_332 guiGraphics, double mouseX, double mouseY) {
        background.draw(guiGraphics);
    }

    @Override
    public @NotNull IDrawable getIcon() {
        return icon;
    }

    @Override
    public void setRecipe(@NotNull IRecipeLayoutBuilder builder, @NotNull OpMakeBattery recipe,
        @NotNull IFocusGroup focuses) {
        var stacks = PhialRecipeStackBuilder.createStacks();

        var inputSlot = builder.addSlot(RecipeIngredientRole.INPUT, 12, 12)
            .addItemStacks(stacks.getFirst());
        builder.addSlot(RecipeIngredientRole.INPUT, 47, 12)
            .addIngredients(class_1856.method_8106(HexTags.Items.PHIAL_BASE));

        var outputSlot = builder.addSlot(RecipeIngredientRole.OUTPUT, 85, 12)
            .addItemStacks(stacks.getSecond());

        builder.createFocusLink(inputSlot, outputSlot);
    }

    @Override
    public @NotNull RecipeType<OpMakeBattery> getRecipeType() {
        return HexJEIPlugin.PHIAL;
    }
}

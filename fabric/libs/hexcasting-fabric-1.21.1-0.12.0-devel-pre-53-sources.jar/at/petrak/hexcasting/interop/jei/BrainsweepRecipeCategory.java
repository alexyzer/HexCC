package at.petrak.hexcasting.interop.jei;

import at.petrak.hexcasting.client.ClientTickCounter;
import at.petrak.hexcasting.common.recipe.BrainsweepRecipe;
import com.mojang.blaze3d.systems.RenderSystem;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.builder.ITooltipBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.drawable.IDrawableStatic;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_638;
import org.jetbrains.annotations.NotNull;

import static at.petrak.hexcasting.api.HexAPI.modLoc;
import static at.petrak.hexcasting.client.render.RenderLib.renderEntity;

public class BrainsweepRecipeCategory implements IRecipeCategory<BrainsweepRecipe> {
    public static final class_2960 UID = modLoc("brainsweep");

    private final IDrawableStatic background;
    private final IDrawable icon;
    private final class_2561 localizedName;

    public BrainsweepRecipeCategory(IGuiHelper guiHelper) {
        class_2960 location = modLoc("textures/gui/brainsweep_recipe.png");
        background = guiHelper.drawableBuilder(location, 0, 0, 118, 86).setTextureSize(128, 128).build();
        var brainsweep = modLoc("brainsweep");
        localizedName = class_2561.method_43471("hexcasting.action." + brainsweep);
        icon = new PatternDrawable(brainsweep, 16, 16);
    }

    @Override
    public @NotNull
    class_2561 getTitle() {
        return localizedName;
    }

    @Override
    public int getWidth() {
        return background.getWidth();
    }

    @Override
    public int getHeight() {
        return background.getHeight();
    }

    @Override
    public @NotNull
    IDrawable getIcon() {
        return icon;
    }

    @Override
    public void getTooltip(ITooltipBuilder tooltip, BrainsweepRecipe recipe, IRecipeSlotsView recipeSlotsView, double mouseX, double mouseY) {
        if (37 <= mouseX && mouseX <= 37 + 26 && 19 <= mouseY && mouseY <= 19 + 48) {
            class_310 mc = class_310.method_1551();
            tooltip.addAll(recipe.entityIn().getTooltip(mc.field_1690.field_1827));
        }
    }

    @Override
    public void draw(@NotNull BrainsweepRecipe recipe, @NotNull IRecipeSlotsView recipeSlotsView, @NotNull class_332 graphics, double mouseX, double mouseY) {
        background.draw(graphics);
        class_638 level = class_310.method_1551().field_1687;
        if (level != null) {
            var examples = recipe.entityIn().exampleEntities(level);
            class_1297 example = null;
            if (!examples.isEmpty()) {
                long seconds = System.currentTimeMillis() / 1000;
                example = examples.get((int) (seconds % examples.size()));
            }
            if (example == null)
                return;

            RenderSystem.enableBlend();
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
            renderEntity(graphics, example, level, 50, 62.5f, ClientTickCounter.getTotal(), 20, 0);
        }
    }

    @Override
    public void setRecipe(@NotNull IRecipeLayoutBuilder builder, @NotNull BrainsweepRecipe recipe,
        @NotNull IFocusGroup focuses) {
        builder.addSlot(RecipeIngredientRole.INPUT, 12, 35)
            .addItemStacks(recipe.blockIn().getDisplayedStacks());
        builder.addSlot(RecipeIngredientRole.OUTPUT, 87, 35)
            .addItemStack(new class_1799(recipe.result().method_26204()));
    }

    @Override
    public @NotNull
    RecipeType<BrainsweepRecipe> getRecipeType() {
        return HexJEIPlugin.BRAINSWEEPING;
    }
}

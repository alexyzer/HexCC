package at.petrak.hexcasting.common.casting.arithmetic.operator.vec;

import at.petrak.hexcasting.api.casting.arithmetic.IterPair;
import at.petrak.hexcasting.api.casting.arithmetic.TripleIterable;
import at.petrak.hexcasting.api.casting.arithmetic.operator.OperatorBasic;
import at.petrak.hexcasting.api.casting.arithmetic.predicates.IotaMultiPredicate;
import at.petrak.hexcasting.api.casting.arithmetic.predicates.IotaPredicate;
import at.petrak.hexcasting.api.casting.eval.CastingEnvironment;
import at.petrak.hexcasting.api.casting.iota.DoubleIota;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.iota.Vec3Iota;
import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.api.casting.mishaps.Mishap;
import at.petrak.hexcasting.api.casting.mishaps.MishapDivideByZero;
import at.petrak.hexcasting.common.casting.arithmetic.DoubleArithmetic;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Objects;
import java.util.function.BiFunction;
import net.minecraft.class_243;

import static at.petrak.hexcasting.common.lib.hex.HexIotaTypes.DOUBLE;
import static at.petrak.hexcasting.common.lib.hex.HexIotaTypes.VEC3;

public class OperatorVec3Delegating extends OperatorBasic {
	private final BiFunction<class_243, class_243, Iota> op;
	private final OperatorBasic fb;
	public OperatorVec3Delegating(BiFunction<class_243, class_243, Iota> core, HexPattern fallback) {
		super(2, IotaMultiPredicate.any(IotaPredicate.ofType(VEC3.get()), IotaPredicate.ofType(DOUBLE.get())));
		op = core;
		fb = (OperatorBasic) Objects.requireNonNull(DoubleArithmetic.INSTANCE.getOperator(fallback));
	}

	@Override
	public @NotNull Iterable<Iota> apply(Iterable<? extends Iota> iotas, @NotNull CastingEnvironment env) throws Mishap {
		var it = iotas.iterator();
		var left = it.next();
		var right = it.next();
		try {
			if (op != null && left instanceof Vec3Iota lh && right instanceof Vec3Iota rh) {
				return List.of(op.apply(lh.getVec3(), rh.getVec3()));
			}
			var lh = left instanceof Vec3Iota l ? l.getVec3() : triplicate(downcast(left, DOUBLE.get()).getDouble());
			var rh = right instanceof Vec3Iota r ? r.getVec3() : triplicate(downcast(right, DOUBLE.get()).getDouble());
			return new TripleIterable<>(
					fb.apply(new IterPair<>(new DoubleIota(lh.x()), new DoubleIota(rh.x())), env),
					fb.apply(new IterPair<>(new DoubleIota(lh.y()), new DoubleIota(rh.y())), env),
					fb.apply(new IterPair<>(new DoubleIota(lh.z()), new DoubleIota(rh.z())), env),
					(x, y, z) -> new Vec3Iota(new Vec3(downcast(x, DOUBLE.get()).getDouble(), downcast(y, DOUBLE.get()).getDouble(), downcast(z, DOUBLE.get()).getDouble()))
			);
		} catch (MishapDivideByZero e) {
			throw MishapDivideByZero.of(left, right, e.getSuffix());
		}
	}

	public static class_243 triplicate(double in) {
		return new class_243(in, in, in);
	}
}
package at.petrak.hexcasting.api.casting.iota;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.casting.ActionRegistryEntry;
import at.petrak.hexcasting.api.casting.PatternShapeMatch;
import at.petrak.hexcasting.api.casting.castables.Action;
import at.petrak.hexcasting.api.casting.eval.*;
import at.petrak.hexcasting.api.casting.eval.sideeffects.OperatorSideEffect;
import at.petrak.hexcasting.api.casting.eval.vm.CastingVM;
import at.petrak.hexcasting.api.casting.eval.vm.FrameEvaluate;
import at.petrak.hexcasting.api.casting.eval.vm.SpellContinuation;
import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.api.casting.mishaps.Mishap;
import at.petrak.hexcasting.api.casting.mishaps.MishapInvalidPattern;
import at.petrak.hexcasting.api.casting.mishaps.MishapUnenlightened;
import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.common.casting.PatternRegistryManifest;
import at.petrak.hexcasting.common.lib.hex.HexEvalSounds;
import at.petrak.hexcasting.common.lib.hex.HexIotaTypes;
import at.petrak.hexcasting.interop.inline.InlinePatternData;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import com.mojang.serialization.MapCodec;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Objects;
import java.util.function.Supplier;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_3218;
import net.minecraft.class_5321;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

import static at.petrak.hexcasting.api.utils.HexUtils.isOfTag;

import CastResult;

public class PatternIota extends Iota {
    private HexPattern value;

    public PatternIota(@NotNull HexPattern pattern) {
        super(() -> HexIotaTypes.PATTERN.get());
        this.value = pattern;
    }

    public HexPattern getPattern() {
        return value;
    }

    @Override
    public boolean isTruthy() {
        return true;
    }

    @Override
    public boolean toleratesOther(Iota that) {
        return typesMatch(this, that)
            && that instanceof PatternIota piota
            && this.getPattern().getSignature().equals(piota.getPattern().getSignature());
    }

    @Override
    public @NotNull CastResult execute(CastingVM vm, class_3218 world, SpellContinuation continuation) {
        return lookupAndOperate(vm, continuation, false);
    }

    @Override
    public @NotNull CastResult executeInParens(CastingVM vm, class_3218 world, SpellContinuation continuation) {
        return lookupAndOperate(vm, continuation, true);
    }

    @Override
    public boolean executable() {
        return true;
    }

    /**
     * Look up this iota's pattern in the action registry, and attempt to invoke the behavior of the resulting Action.
     * If {@code inParens} is false, the {@link Action#operate} method is used, and patterns lacking a matching Action will mishap.
     * If {@code inParens} is true, the {@link Action#operateInParens} method is used instead, and patterns lacking a matching Action
     * will be added to the in-progress parenthesized list as usual.
     * In either case, any mishaps thrown during the lookup or operation process will be caught, and an appropriate
     * CastResult will be returned.
     */
    private @NotNull CastResult lookupAndOperate(CastingVM vm, SpellContinuation continuation, boolean inParens) {
        Supplier<@Nullable class_2561> castedName = () -> null;
        try {
            var lookup = PatternRegistryManifest.matchPattern(this.getPattern(), vm.getEnv());
            vm.getEnv().precheckAction(lookup);

            Action action;
            if (lookup instanceof PatternShapeMatch.Normal || lookup instanceof PatternShapeMatch.PerWorld) {
                class_5321<ActionRegistryEntry> key;
                if (lookup instanceof PatternShapeMatch.Normal normal) {
                    key = normal.key;
                } else {
                    PatternShapeMatch.PerWorld perWorld = (PatternShapeMatch.PerWorld) lookup;
                    key = perWorld.key;
                }

                var reqsEnlightenment = isOfTag(IXplatAbstractions.INSTANCE.getActionRegistry(), key,
                    HexTags.Actions.REQUIRES_ENLIGHTENMENT);

                castedName = () -> HexAPI.instance().getActionI18n(key, reqsEnlightenment);
                action = Objects.requireNonNull(IXplatAbstractions.INSTANCE.getActionRegistry().method_29107(key)).action();

                if (reqsEnlightenment && !vm.getEnv().isEnlightened()) {
                    // this gets caught down below
                    throw new MishapUnenlightened();
                }
            } else if (lookup instanceof PatternShapeMatch.Special special) {
                castedName = special.handler::getName;
                action = special.handler.act();
            } else if (lookup instanceof PatternShapeMatch.Nothing) {
                if (inParens) {
                    // invalid patterns still get added to the list when in parens
                    return new CastResult(
                        this,
                        continuation,
                        vm.getImage().withNewParenthesized(this, false),
                        List.of(),
                        ResolvedPatternType.ESCAPED,
                        HexEvalSounds.NORMAL_EXECUTE.get());
                } else {
                    // if you draw something invalid outside parens, it mishaps
                    throw new MishapInvalidPattern(this.getPattern());
                }
            } else throw new IllegalStateException();

            IOperationResult result;
            ResolvedPatternType resolutionType;
            if (inParens) {
                // handle parenthesized behavior
                result = action.operateInParens(
                    vm.getEnv(),
                    vm.getImage(),
                    continuation,
                    this
                );
                resolutionType = ((ParenthesizedOperationResult)result).getResolutionType();
            } else {
                // do the actual calculation!!
                result = action.operate(
                    vm.getEnv(),
                    vm.getImage(),
                    continuation
                );
                resolutionType = ResolvedPatternType.EVALUATED;
            }

            var cont2 = result.getNewContinuation();
            // TODO parens also break prescience
            var sideEffects = result.getSideEffects();

            return new CastResult(
                this,
                cont2,
                result.getNewImage(),
                sideEffects,
                resolutionType,
                result.getSound());

        } catch (Mishap mishap) {
            // If a mishap happens mid-parens at the top level (ie when staffcasting), keep any in-progress parens.
            // If a mishap happens mid-parens while metacasting, wipe the parens - if we didn't do this, any open paren
            // levels would remain open even though the metacast itself has mishapped and thus been aborted.
            boolean wipeParens = continuation instanceof SpellContinuation.NotDone cnd
                              && cnd.getFrame() instanceof FrameEvaluate frameEval
                              && frameEval.isMetacasting();
            return new CastResult(
                this,
                continuation,
                wipeParens ? vm.getImage().withResetEscape() : null,
                List.of(new OperatorSideEffect.DoMishap(mishap, new Mishap.Context(this.getPattern(), castedName.get()))),
                mishap.resolutionType(vm.getEnv()),
                HexEvalSounds.MISHAP.get());
        }
    }

    @Override
    public int hashCode() {
        return value.hashCode();
    }

    @Override
    public class_2561 display() {
        return PatternIota.display(getPattern());
    }

    public static IotaType<PatternIota> TYPE = new IotaType<>() {
        public static final MapCodec<PatternIota> CODEC = HexPattern.CODEC
                .xmap(PatternIota::new, PatternIota::getPattern)
                .fieldOf("value");
        public static final class_9139<class_9129, PatternIota> STREAM_CODEC =
                HexPattern.STREAM_CODEC.method_56432(PatternIota::new, PatternIota::getPattern);

        @Override
        public MapCodec<PatternIota> codec() {
            return CODEC;
        }

        @Override
        public class_9139<class_9129, PatternIota> streamCodec() {
            return STREAM_CODEC;
        }

        @Override
        public int color() {
            return 0xff_ffaa00;
        }

        @Override
        public boolean usesListCommas() {
            return false;
        }
    };

    public static class_2561 display(HexPattern pat) {
        class_2561 text = (new InlinePatternData(pat)).asText(true);
        return text.method_27661().method_27696(text.method_10866().method_27702(class_2583.field_24360.method_10977(class_124.field_1068)));
    }

    // keep around just in case it's needed.
    public static class_2561 displayNonInline(HexPattern pat){
        var bob = new StringBuilder();
        bob.append(pat.getOrientation());

        var sig = pat.getSignature();
        if (sig.sizeUpperBound() > 0) {
            bob.append(" ");
            bob.append(sig.toAnglesString());
        }
        return class_2561.method_43469("hexcasting.tooltip.pattern_iota",
                        class_2561.method_43470(bob.toString()).method_27692(class_124.field_1068))
                .method_27692(class_124.field_1065);
    }
}

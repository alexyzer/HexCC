package at.petrak.hexcasting.common.lib;

import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1533;
import net.minecraft.class_1542;
import net.minecraft.class_1799;

public class HexItemHolderHandlers {
    private static Map<class_1299<?>, Function<? extends class_1297, class_1799>> REGISTRY = new HashMap<>();

    /**
     * Register a handler for mapping an entity type to an item.
     *
     * @param type    Type of entity to register the handler for.
     * @param handler The handler function. May return null, in which case dependent patterns will mishap.
     */
    public static <T extends class_1297> void register(class_1299<T> type, Function<T, class_1799> handler) {
        REGISTRY.put(type, handler);
    }

    @SuppressWarnings("unchecked")
    public static @Nullable class_1799 applyHandlerFor(class_1297 e) {
        var handler = REGISTRY.getOrDefault(e.method_5864(), entity -> null);
        class_1799 stack = ((Function<class_1297, class_1799>) handler).apply(e);

        if (stack != null && stack.method_7960()) stack = null;

        return stack;
    }

    public static void init() {
        register(class_1299.field_6052, class_1542::method_6983);
        register(class_1299.field_6043, class_1533::method_6940);
        register(class_1299.field_6097, player -> {
            class_1799 mainHand = player.method_5998(class_1268.field_5808);
            if (!mainHand.method_7960()) return mainHand;
            return player.method_5998(class_1268.field_5810);
        });
    }
}

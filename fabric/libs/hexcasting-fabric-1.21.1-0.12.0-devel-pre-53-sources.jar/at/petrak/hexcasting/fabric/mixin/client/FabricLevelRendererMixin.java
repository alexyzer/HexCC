package at.petrak.hexcasting.fabric.mixin.client;

import at.petrak.hexcasting.fabric.xplat.FabricClientXplatImpl;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_4184;
import net.minecraft.class_4604;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_765;
import net.minecraft.class_9779;

@Mixin(class_761.class)
public class FabricLevelRendererMixin {
    @Inject(
        method = "renderLevel",
        at = @At(
            value = "INVOKE", target = "Lnet/minecraft/client/renderer/FogRenderer;levelFogColor()V",
            ordinal = 0)
    )
    private void snagFrustumFromLevelRenderer(class_9779 deltaTracker, boolean bl, class_4184 camera, class_757 gameRenderer,
                                              class_765 lightTexture, Matrix4f matrix4f, Matrix4f matrix4f2,
                                              CallbackInfo ci, @Local class_4604 frustum) {
        FabricClientXplatImpl.LEVEL_RENDERER_FRUSTUM = frustum;
    }
}

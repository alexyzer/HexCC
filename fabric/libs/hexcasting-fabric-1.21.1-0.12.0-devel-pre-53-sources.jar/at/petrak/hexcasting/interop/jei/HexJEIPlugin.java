package at.petrak.hexcasting.interop.jei;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.common.casting.actions.spells.OpEdifySapling;
import at.petrak.hexcasting.common.casting.actions.spells.OpMakeBattery;
import at.petrak.hexcasting.common.items.ItemStaff;
import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.hexcasting.common.recipe.BrainsweepRecipe;
import at.petrak.hexcasting.common.recipe.HexRecipeStuffRegistry;
import at.petrak.hexcasting.interop.utils.PhialRecipeStackBuilder;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.registration.IRecipeCatalystRegistration;
import mezz.jei.api.registration.IRecipeCategoryRegistration;
import mezz.jei.api.registration.IRecipeRegistration;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_8786;
import org.jetbrains.annotations.NotNull;

import java.util.List;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

@JeiPlugin
public class HexJEIPlugin implements IModPlugin {
    private static final class_2960 UID = modLoc(HexAPI.MOD_ID);

    public static final RecipeType<BrainsweepRecipe> BRAINSWEEPING =
        RecipeType.create(HexAPI.MOD_ID, "brainsweeping", BrainsweepRecipe.class);

    // Only one entry, might as well use the op class
    public static final RecipeType<OpMakeBattery> PHIAL =
        RecipeType.create(HexAPI.MOD_ID, "craft_phial", OpMakeBattery.class);
    public static final RecipeType<OpEdifySapling> EDIFY =
        RecipeType.create(HexAPI.MOD_ID, "edify_tree", OpEdifySapling.class);

    @NotNull
    @Override
    public class_2960 getPluginUid() {
        return UID;
    }

    @Override
    public void registerCategories(IRecipeCategoryRegistration registration) {
        var guiHelper = registration.getJeiHelpers().getGuiHelper();
        registration.addRecipeCategories(
            new BrainsweepRecipeCategory(guiHelper),
            new PhialRecipeCategory(guiHelper),
            new EdifyRecipeCategory(guiHelper));
    }

    @Override
    public void registerRecipes(@NotNull IRecipeRegistration registration) {
        class_1937 level = class_310.method_1551().field_1687;
        if (level != null) {
            registration.addRecipes(BRAINSWEEPING,
                level.method_8433().method_30027(HexRecipeStuffRegistry.BRAINSWEEP_TYPE.get()).stream().map(class_8786::comp_1933).toList());
        }

        if (PhialRecipeStackBuilder.shouldAddRecipe()) {
            registration.addRecipes(PHIAL, List.of(OpMakeBattery.INSTANCE));
        }

        registration.addRecipes(EDIFY, List.of(OpEdifySapling.INSTANCE));
    }

    @Override
    public void registerRecipeCatalysts(IRecipeCatalystRegistration registration) {
        for (ItemStaff staff : new ItemStaff[]{
            HexItems.STAFF_OAK.get(),
            HexItems.STAFF_SPRUCE.get(),
            HexItems.STAFF_BIRCH.get(),
            HexItems.STAFF_JUNGLE.get(),
            HexItems.STAFF_ACACIA.get(),
            HexItems.STAFF_DARK_OAK.get(),
            HexItems.STAFF_CRIMSON.get(),
            HexItems.STAFF_WARPED.get(),
            HexItems.STAFF_MANGROVE.get(),
            HexItems.STAFF_CHERRY.get(),
            HexItems.STAFF_BAMBOO.get(),
            HexItems.STAFF_EDIFIED.get(),
        }) {
            registration.addRecipeCatalyst(new class_1799(staff), BRAINSWEEPING, PHIAL, EDIFY);
        }
    }
}

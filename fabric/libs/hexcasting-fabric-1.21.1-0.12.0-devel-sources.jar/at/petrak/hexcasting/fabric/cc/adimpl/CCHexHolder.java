package at.petrak.hexcasting.fabric.cc.adimpl;

import at.petrak.hexcasting.api.addldata.ADHexHolder;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.item.HexHolderItem;
import at.petrak.hexcasting.api.pigment.FrozenPigment;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;
import org.ladysnake.cca.api.v3.component.Component;

import java.util.List;

public abstract class CCHexHolder implements ADHexHolder, Component {
    final ItemStack stack;
    public CCHexHolder(ItemStack stack) {
        this.stack = stack;
    }

    public static class ItemBased extends CCHexHolder {
        private final HexHolderItem hexHolder;

        public ItemBased(ItemStack owner) {
            super(owner);
            var item = owner.getItem();
            if (!(item instanceof HexHolderItem hexHolderItem)) {
                throw new IllegalStateException("item is not a pigment: " + owner);
            }
            this.hexHolder = hexHolderItem;
        }


        @Override
        public boolean canDrawMediaFromInventory() {
            return this.hexHolder.canDrawMediaFromInventory(this.stack);
        }

        @Override
        public boolean hasHex() {
            return this.hexHolder.hasHex(this.stack);
        }

        @Override
        public @Nullable List<Iota> getHex(ServerLevel level) {
            return this.hexHolder.getHex(this.stack, level);
        }

        @Override
        public void writeHex(List<Iota> patterns, @Nullable FrozenPigment pigment, long media) {
            this.hexHolder.writeHex(this.stack, patterns, pigment, media);
        }

        @Override
        public void clearHex() {
            this.hexHolder.clearHex(this.stack);
        }

        @Override
        public @Nullable FrozenPigment getPigment() {
            return this.hexHolder.getPigment(this.stack);
        }

        @Override
        public void readFromNbt(CompoundTag tag, HolderLookup.Provider registryLookup) {

        }

        @Override
        public void writeToNbt(CompoundTag tag, HolderLookup.Provider registryLookup) {

        }
    }
}

package at.petrak.hexcasting.interop.jei;

import at.petrak.hexcasting.common.casting.actions.spells.OpEdifySapling;
import at.petrak.hexcasting.common.lib.HexBlocks;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.drawable.IDrawableStatic;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3489;
import org.jetbrains.annotations.NotNull;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class EdifyRecipeCategory implements IRecipeCategory<OpEdifySapling> {
    public static final class_2960 UID = modLoc("edify_tree");

    private final IDrawableStatic background;
    private final IDrawable icon;
    private final class_2561 localizedName;

    public EdifyRecipeCategory(IGuiHelper guiHelper) {
        class_2960 location = modLoc("textures/gui/edify_recipe.png");
        background = guiHelper.drawableBuilder(location, 0, 0, 79, 61).setTextureSize(128, 128).build();
        var edify = modLoc("edify");
        localizedName = class_2561.method_43471("hexcasting.action." + edify);
        icon = new PatternDrawable(edify, 16, 16).strokeOrder(false);
    }

    @Override
    public @NotNull class_2561 getTitle() {
        return localizedName;
    }

    @Override
    public int getWidth() {
        return background.getWidth();
    }

    @Override
    public int getHeight() {
        return background.getHeight();
    }

    @Override
    public void draw(OpEdifySapling recipe, IRecipeSlotsView recipeSlotsView, class_332 guiGraphics, double mouseX, double mouseY) {
        background.draw(guiGraphics);
    }

    @Override
    public @NotNull IDrawable getIcon() {
        return icon;
    }

    @Override
    public void setRecipe(@NotNull IRecipeLayoutBuilder builder, @NotNull OpEdifySapling recipe,
        @NotNull IFocusGroup focuses) {
        builder.addSlot(RecipeIngredientRole.INPUT, 12, 22)
            .addIngredients(class_1856.method_8106(class_3489.field_15528));

        builder.addSlot(RecipeIngredientRole.OUTPUT, 51, 10)
            .addItemStack(new class_1799(HexBlocks.AMETHYST_EDIFIED_LEAVES.get()))
            .addItemStack(new class_1799(HexBlocks.AVENTURINE_EDIFIED_LEAVES.get()))
            .addItemStack(new class_1799(HexBlocks.CITRINE_EDIFIED_LEAVES.get()));
        builder.addSlot(RecipeIngredientRole.OUTPUT, 51, 35)
            .addItemStack(new class_1799(HexBlocks.EDIFIED_LOG.get()))
            .addItemStack(new class_1799(HexBlocks.EDIFIED_LOG_AMETHYST.get()))
            .addItemStack(new class_1799(HexBlocks.EDIFIED_LOG_AVENTURINE.get()))
            .addItemStack(new class_1799(HexBlocks.EDIFIED_LOG_CITRINE.get()));
//            .addItemStack(new ItemStack(HexBlocks.EDIFIED_LOG_PURPLE.get()));

    }

    @Override
    public @NotNull RecipeType<OpEdifySapling> getRecipeType() {
        return HexJEIPlugin.EDIFY;
    }
}
